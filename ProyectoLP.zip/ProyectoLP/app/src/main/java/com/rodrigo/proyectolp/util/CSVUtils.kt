package com.rodrigo.proyectolp.util

import android.content.Context
import com.rodrigo.proyectolp.data.Cancion
import java.io.BufferedReader
import java.io.InputStreamReader

// Función para leer el archivo CSV
fun leerCSV(context: Context): List<String> {
    val listaCancion = mutableListOf<String>()
    try {
        val inputStream = context.assets.open("genres_v2.csv")
        val lector = BufferedReader(InputStreamReader(inputStream))
        lector.readLine() // Salta el encabezado, si existe
        lector.forEachLine { line ->
            listaCancion.add(line)
        }
        lector.close()
        println("Líneas leídas del CSV: ${listaCancion.size}")
        listaCancion.forEach { println(it) } // Imprime cada línea para verificar el contenido
    } catch (e: Exception) {
        e.printStackTrace()
    }
    return listaCancion
}

// Limpiar y convertir los datos del archivo CSV
fun limpiarDatos(rawData: List<String>): List<Cancion> {
    return rawData.mapNotNull { line ->
        val tokens = line.split(",") // Ajusta el delimitador según el formato del CSV

        try {
            val danceability = tokens[0].replace("'", "").toDoubleOrNull()
            val energy = tokens[1].toDoubleOrNull()
            val acousticness = tokens[6].toDoubleOrNull()
            val durationMs = tokens[16].toIntOrNull()
            val durationSeconds = durationMs?.div(1000) ?: 0

            if (danceability != null && energy != null && acousticness != null && durationSeconds > 0) {
                Cancion(
                    id = tokens[12],
                    title = tokens[19],
                    danceability = danceability,
                    energy = energy,
                    acousticness = acousticness,
                    duration = durationSeconds,
                    genre = tokens[18]
                )
            } else {
                null
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
