package com.rodrigo.proyectolp.data

data class Cancion(
    val id: String,
    val title: String,
    val danceability: Double,
    val energy: Double,
    val acousticness: Double,
    val duration: Int, // Duración en segundos
    val genre: String
)
