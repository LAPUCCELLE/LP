package com.rodrigo.proyectolp.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.rodrigo.proyectolp.data.Cancion
import com.rodrigo.proyectolp.data.Usuario
import com.rodrigo.proyectolp.theme.ProyectoLPTheme
import com.rodrigo.proyectolp.util.leerCSV
import com.rodrigo.proyectolp.util.limpiarDatos
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ProyectoLPTheme {
                MainScreen()
            }
        }
    }
}

@Composable
fun MainScreen() {
    val context = LocalContext.current

    // Variables de estado para almacenar datos por entrada del usuario
    var minDanceability by remember { mutableStateOf("") }
    var maxDanceability by remember { mutableStateOf("") }
    var genre by remember { mutableStateOf("") }
    var recommendedSongs by remember { mutableStateOf(listOf<Cancion>()) }
    var originalPlaylist by remember { mutableStateOf(listOf<Cancion>()) }
    //Lista para la playlist Original del usuario

    // Cargar y limpiar los datos del CSV
    val rawData = leerCSV(context)
    val canciones = limpiarDatos(rawData)

    // Creamos una instancia de usuario con la playlist Original
    val usuario = Usuario("User1")

    //Se añade canciones a la playlist original del Usuario
    if (originalPlaylist.isEmpty()){
        originalPlaylist = canciones.take(10) //Agregar las primeras 10 canciones del CSV
        originalPlaylist.forEach{ usuario.addToPlayList(it)}
    }

    val scrollState = rememberScrollState() // Para manejar el scroll

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) { innerPadding ->
            Column(
                modifier = Modifier.padding(innerPadding).verticalScroll(scrollState)
            ){
                Text(text = "Ingrese los filtros de búsqueda: ")

            // Campos de entrada para los filtros
            BasicTextField(
                value = minDanceability,
                onValueChange = { minDanceability = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                decorationBox = { innerTextField ->
                    if (minDanceability.isEmpty()) {
                        Text(text = "Min Danceability")
                    }
                    innerTextField()
                }
            )

            BasicTextField(
                value = maxDanceability,
                onValueChange = { maxDanceability = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                decorationBox = { innerTextField ->
                    if (maxDanceability.isEmpty()) {
                        Text(text = "Max Danceability")
                    }
                    innerTextField()
                }
            )

            BasicTextField(
                value = genre,
                onValueChange = { genre = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                decorationBox = { innerTextField ->
                    if (genre.isEmpty()) {
                        Text(text = "Género")
                    }
                    innerTextField()
                }
            )

            Button(
                onClick = {
                    // Convertir los valores de entrada y aplicar el filtrado
                    val minDance = minDanceability.toDoubleOrNull() ?: 0.0
                    val maxDance = maxDanceability.toDoubleOrNull() ?: 1.0

                    //Imprime los valores de entrada para verificar que se lean correctamente
                    println("Min Danceability: $minDance")
                    println("Max Danceability: $maxDance")
                    println("Genre: $genre")

                    // Filtrar las canciones según los criterios del usuario
                    recommendedSongs = canciones.filter { cancion ->
                        cancion.danceability in minDance..maxDance &&
                                (genre.isEmpty() || cancion.genre.equals(genre, ignoreCase = true)) &&
                                !usuario.getPlayList().contains(cancion) // Excluir canciones ya agregadas
                    }

                    // Añadir las canciones recomendadas al playlist del usuario
                    recommendedSongs.forEach { usuario.addToPlayList(it) }

                    // Imprime la cantidad de canciones encontradas y los nombres
                    println("Canciones recomendadas: ${recommendedSongs.size}")
                    recommendedSongs.forEach { println("Canción: ${it.title}, Danceability: ${it.danceability}, Genre: ${it.genre}") }
                    /* Esta parte se verá en el LOGCAT*/

                },
                modifier = Modifier.padding(vertical = 16.dp)
            ) {
                Text(text = "Generar Playlist")
            }
                Spacer(modifier = Modifier.height(8.dp))

                //Mostrar playlist original del usuario

                Text(text = "Playlist original del Usuario:",
                    style=androidx.compose.material3.Typography().headlineSmall)

                Spacer(modifier = Modifier.height(8.dp))

                usuario.getPlayList().forEach { cancion -> Text(text = "- ${cancion.title} " +
                        "(Genero: ${cancion.genre}")
                }

                Spacer(modifier = Modifier.height(16.dp))

            // Mostrar la lista de canciones recomendadas
                Text(
                    text = "Canciones recomendadas: ${recommendedSongs.size}",
                    style = androidx.compose.material3.Typography().headlineMedium
                )
                Spacer(modifier = Modifier.height(16.dp))
                    recommendedSongs.   forEach { cancion ->
                        Text(text = "-${cancion.title}")
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun MainScreenPreview() {
    ProyectoLPTheme {
        MainScreen()
    }
}
