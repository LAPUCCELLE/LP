package com.rodrigo.proyectolp.data

class Usuario(val id: String) {
    private val playlist = mutableListOf<Cancion>()

    fun addToPlayList(cancion:Cancion){
        if(!playlist.contains(cancion)){
            playlist.add(cancion)
        }
    }
    fun getPlayList(): List<Cancion> = playlist
}